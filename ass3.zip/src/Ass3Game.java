// ID: 320518020

/**
 *
 *
 * @author Gidon tobin
 * @version 1.0 27 April 2021
 */

public class Ass3Game {
    /**
     * The entry point of application.
     *
     * @param args the input arguments
     */
    public static void main(String[] args) {
        Game game = new Game();
        game.initialize();
        game.run();
    }
}
